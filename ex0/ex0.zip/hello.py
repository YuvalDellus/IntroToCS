############################################################
# FILE : hello.py
# WRITER : Yuval Dellus , yuval_dellus, 305211880
# EXERCISE : intro2cs ex0 2016-2017
# DESCRIPTION : A simple program theat prints "Hello World" to
# the standard output (screen).
############################################################

print("Hello World!")